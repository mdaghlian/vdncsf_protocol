function params = getRetinotopyParams;
% getRetinotopyParams;

