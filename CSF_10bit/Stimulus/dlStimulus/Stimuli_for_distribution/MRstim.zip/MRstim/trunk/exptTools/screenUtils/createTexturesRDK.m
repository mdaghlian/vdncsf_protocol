function stimulus = createTexturesRDK(display, stimulus, removeImages);
%stimulus = createTextures(display, stimulus, [removeImages=1]);
%
%Replace images within stimulus (stimulus.image) with textures
%(stimulus.textures).
%
%Stimulus can be a 1xn array of stimuli.  It creates the textures
%(like loading in off-screen memory in OS9).
% If the removeImages flag is set to 1 [default value], the code
% destroys the original image field (freeing up the memory and speeding up
% pass-by-copy calls of stimulus). For stimuli with many images, this is
% strongly recommended; however, for a small number of images, the field
% may not slow things too much; setting the flag to 0 keeps the images.
%
%If you're trying to create an texture starting at something
%other than the first image, use addTextures.

%2005/06/09   SOD: ported from createImagePointers
%31102005    fwc:	changed display.screenNumber into display.windowPtr
if notDefined('removeImages'),      removeImages = 1;       end

%c = getReservedColor(display, 'background');
try,
	c = display.backColorIndex;
catch,
	c = display.backColorRgb;
end;

% rect=[0 0 display.numPixels display.numPixels];
% [w rect] = Screen('OpenWindow', display.windowPtr, 128, rect, 32);

for stimNum = 1:length(stimulus)

	% if stored as cell?!
	% maybe everything should be cell based and not based on the 3 image
	% dimension - this would allow easy support for rgb images
	if iscell(stimulus(stimNum).images),
		stimulus(stimNum).images = cell2mat(stimulus(stimNum).images);
	end;

	% number of images
	nImages = size(stimulus(stimNum).images,3);

	% make Rects
	stimulus(stimNum).srcRect = [0,0,size(stimulus(stimNum).images, 2), ...
		size(stimulus(stimNum).images, 1)];
	if ~isfield(display,'Rect'),
		stimulus(stimNum).destRect = CenterRect(stimulus(stimNum).srcRect, display.rect);
    else
		stimulus(stimNum).destRect = display.Rect;
	end;

	% clean up nicely if any of the textures are not null.
	if isfield(stimulus(stimNum), 'textures'),
		nonNull = find(stimulus(stimNum).textures);
		for i=1:length(nonNull),
			% run this from eval to suppress any errors that might ensue if the texture isn't valid
			eval('Screen(stimulus(stimNum).textures(nonNull(i)), ''Close'');', '[];');
		end;
	end;
	stimulus(stimNum).textures = zeros(nImages, 1);
    
	% make textures
	for imgNum = 1:nImages,
        %jw: flip for back bore inverted display
        if (isfield(display, 'flipLR') && display.flipLR),
            stimulus(stimNum).images(:,:,imgNum) = fliplr(stimulus(stimNum).images(:,:,imgNum));
        end
        if (isfield(display, 'flipUD') &&display.flipUD),
            stimulus(stimNum).images(:,:,imgNum) = flipud(stimulus(stimNum).images(:,:,imgNum));
        end        
        
        dotPattern=stimulus.images(:,:,imgNum);
        dotPattern=dotPattern(dotPattern<55555);
        dotPattern=reshape(dotPattern, 2, length(dotPattern)/2); 
        
        cols=stimulus.images(1,:,imgNum)<55555;
        dotColors=stimulus.seq.colors(cols==1);
        dotColors=repmat(dotColors,3,1);
        
        
        %Screen('FillRect', display.windowPtr, [128 128 128], rect );
       
        imgIndex=Screen('OpenOffScreenWindow', display.windowPtr, 128, stimulus(stimNum).srcRect);
        if size(dotPattern,2)>0
            Screen('DrawDots',imgIndex, double(dotPattern), double(stimulus.seq.size), double(dotColors), [display.Rect(1) display.Rect(2)],1);
        end
        dotImage=Screen('GetImage', imgIndex);
        
        stimulus(stimNum).textures(imgNum) = Screen('MakeTexture',display.windowPtr,dotImage);
	end;
    
    if isfield(stimulus, 'pictures')
        for pictNum=1:length(stimulus.pictures)
            stimulus(stimNum).textures(nImages+((pictNum-1)*2+1)) = Screen('MakeTexture',display.windowPtr, double(stimulus.pictures(pictNum).circleimage1));
            stimulus(stimNum).textures(nImages+((pictNum-1)*2+2)) = Screen('MakeTexture',display.windowPtr, double(stimulus.pictures(pictNum).circleimage2));
        end
    end

	% clean up
	if removeImages==1
		stimulus(stimNum).images = [];
	end
end;

% call/load 'DrawTexture' prior to actual use (clears overhead)
Screen('DrawTexture', display.windowPtr, stimulus(1).textures(1), ...
	stimulus(1).srcRect, stimulus(1).destRect);

return
