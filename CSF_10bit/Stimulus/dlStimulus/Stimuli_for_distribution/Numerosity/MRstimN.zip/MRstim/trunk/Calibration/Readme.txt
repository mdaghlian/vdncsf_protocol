Simple program to present different mean luminance screens for calibration.
